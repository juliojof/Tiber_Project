The Tiber WATS dataset distribution consists of five different
subsets of a commercial Wide Azimuth Towed Streamer seismic
dataset acquired over the Tiber field in the U.S. deep-water
Gulf of Mexico in 2010, along with an associated anisotropic
velocity model to use for migrating the seismic data. Bp is
releasing the data with the aim of facilitating the creation
of new imaging algorithms and workflows that may create
higher-resolution images beneath complex salt than is currently
possible. The datasets are being released as a package under
a Creative Commons Attribution-NonCommercial-ShareAlike 4.0
International license (CC BY-NC-SA 4.0) in 2020. 

The document "Tiber Summary Doc" in the Tiber_WATS_Master_Doc
directory describes the geological setting of the dataset and
the imaging goals, and shows some example migrated sections
using these data and velocity model. It also includes more
detailed copyright information, describing the full terms
of use of the data. 

The document "Tiber Technical Doc" in the same directory
describes the five datasets provided in detail, supplying all
the information you should need to work with these data. It
also describes how the data are split across multiple files,
such that it is not necessary to download complete datasets
to begin using the data to evaluate novel imaging approaches.
Each of the five datasets and the velocity model are in a
separate directory, with a README file and a LICENSE file
in each directory. 

To image these data you will require 1) part, or all of,
at least one of the five seismic data subsets, 2) the master
documentation directory, and 3) the velocity model directory.

Please read the documentation files first before beginning
work using the data. Please do not separate the documentation
from the data. See the LICENSE.txt file for more detail
about how best to do that.

For distribution purposes all the small ancillary files
associated with a dataset may be zip'd together into a
zip archive "dataset_name".zip, where dataset_name is one of:

MasterDoc
Velocity
PPLarge
PPSmall
RawLarge
RawSmall
RawSmallDec

There should also be a file ""dataset_name".list.txt, which
lists all the files in the corresponding zip. This file will
be in the Tiber_WATS_Master_Doc directory.

The zip files are all made to be unpacked at the level of
the top-level directory (where the file "README_FIRST" is
located).

------------------------------------------------------

The data are broken into five different subsets.
Each of these subsets can be used independently.

 1) PP_Small_Final
 2) Raw_Small_Final
 3) Raw_Smalldec_Final
 4) PP_Large_Final
 5) Raw_Large_Final

You will need the other two directories regardless of which
data subset you are using:

  Tiber_WATS_Master_Doc
    The five data subsets are described in detail here.

  Tiber_WATS_Velocity
    The velocity model.

Each directory has its own README file specific to that
directory as well.

Files ending in ".gz" have been compressed using the UNIX
"gzip" program. Files ending in "zip" have been archived
using the classic windows "zip" format. Standard tools in
both Windows and Unix/Linux should be able to handle these
formats.

Thu Jan 21 12:25:59 CST 2021
