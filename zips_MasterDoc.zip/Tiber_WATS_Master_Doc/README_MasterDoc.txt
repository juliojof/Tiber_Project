The 2020 Tiber WATS data distribution is
(C) 2020 BP Exploration and Production Inc.
----------------------------------------------

This is the master documentation directory.
All the documentation for the 2020 Tiber WATS distribution
should be here, except for the documentation for the velocity
model, which is in the directory with the velocity model.

README_MasterDoc.txt
	This file.

LICENSE.txt
	A summary of the license and terms of use
	for the data distribution.

Tiber_Summary_Doc.docx
	A basic description of the datasets and the area.
	Also contains the full license and terms of use.

Tiber_Technical_Doc.docx
	Technical description of the five available data
	subsets. It is possible to do useful work with only
	a limited amount of data. This document will tell
	you how the data are organized so that you can download
	small useful subsets.

Areas_of_interest.txt
	Coordinates of the "large" and "small" full-fold
	imaging areas.

EBCDIC_HEADER_PP.txt
EBCDIC_HEADER_RAW.txt
	Examples of the original SEGY EBCDIC headers that came
	with the raw data.

Figures
	Copies of all the various figures included in the
	documentation.

Lists of files in zip archives:
	MasterDoc.list.txt
	PPLarge.list.txt
	PPSmall.list.txt
	RawLarge.list.txt
	RawSmallDec.list.txt
	RawSmall.list.txt
	Velocity.list.txt
