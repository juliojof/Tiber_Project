The files in this area specify the TTI velocity model for the
Tiber WATS dataset, as of 2018. Some of the files have been
split along the 3rd axis to keep the compressed files below
2G apiece. 

Doc.Velocity
This directory contains
  LICENSE.txt: The license file
  Anisotropy.txt: definition of the TTI velocity parameters
  UNITS.txt: definition of the geometry of the velocity file
  HEADER.txt: the original SEGY header
  Tiber_Vel_doc.docx: Full Documentation of the velocity file

SEGY.Velocity
This directory contains all six components of the
Velocity cube, broken into 2G chunks and compressed using gzip.
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Delta.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Epsilon.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Phi.p1.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Phi.p2.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Phi.p3.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Phi.p4.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Phi.p5.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Phi.p6.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_P.p1.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_P.p2.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_P.p3.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_P.p4.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_P.p5.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_P.p6.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Theta.p1.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Theta.p2.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Theta.p3.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Theta.p4.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Theta.p5.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Theta.p6.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Vertical.p1.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Vertical.p2.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Vertical.p3.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Vertical.p4.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Vertical.p5.segy.gz
  SEGY.Velocity/Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Vertical.p6.segy.gz

Doc.Velocity/Stats.Velocity
This directory contains statistics for each velocity file,
notably the minimum and maximum for each velocity component.
The velocity model is incomplete at its NE and SE corners,
and all the files have zeroes there. The statistics were
therefore calculated after ignoring all zero values as
representing "holes". However, for some of the files zero
could also be a valid value. Use the zeroes in the "P" file
to identify the holes.
  Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Delta.stats
  Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Epsilon.stats
  Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Phi.stats
  Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_P.stats
  Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Theta.stats
  Vel.2018_TIGRIS_StagSeis_CGG_finalmodel_Vertical.stats
